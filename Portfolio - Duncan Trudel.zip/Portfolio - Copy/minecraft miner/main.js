
document.getElementById('getwood').addEventListener('click', obtainwood);
document.getElementById('getmetals').addEventListener('click', obtainmetal);
document.getElementById('getgems').addEventListener('click', obtaingems);


let numwood = 0;
let numiron = 0;
let numquartz = 0;
let numcoal = 0;
let numgold = 0;
let numdiamonds = 0;
let numemeralds = 0;

let selecress = 1;
let selectnum = 1;
//Big Functions

function obtainwood() {
    determineressource(1, 2);
    determineamount(4, 5);
    add();
}


function obtainmetal() {
    determineressource(2, 6);
    determineamount(1, 5);
    add();
    console.log(selecress)
}


function obtaingems() {
    determineressource(6, 8);
    determineamount(1, 3);
    add();
}





//Small Functions

function determineressource(a, b) {
    selecress = Math.randomInt(a, b);
}

function determineamount(a, b) {
    selectnum = Math.randomInt(a, b);
}

function add() {

    //wood
    if (selecress == 1) {
        numwood += selectnum;
        document.getElementById('wood').innerHTML = numwood;
    } else if (selecress == 2) {
        numiron += selectnum * 2;
        document.getElementById('iron').innerHTML = numiron;
    } else if (selecress == 3) {
        numquartz += selectnum * 2;
        document.getElementById('quartz').innerHTML = numquartz;
    } else if (selecress == 4) {
        numcoal += selectnum * 3;
        document.getElementById('coal').innerHTML = numcoal;
    } else if (selecress == 5) {
        numgold += selectnum;
        document.getElementById('gold').innerHTML = numgold;
    } else if (selecress == 6) {
        numdiamonds += selectnum;
        document.getElementById('diamonds').innerHTML = numdiamonds;
    } else if (selecress == 7) {
        numemeralds += selectnum;
        document.getElementById('emeralds').innerHTML = numemeralds;
    }

}

