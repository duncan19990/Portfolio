
document.getElementById('go').addEventListener('click', selectciv);

let cnv = document.getElementById("mycanvas");
let ctx = cnv.getContext("2d");
cnv.width = 800;
cnv.height = 600;


let emp1 = [];
let emp2 = [];
let emp3 = [];
let emp4 = [];
let names = ["Bretzelburg", "Borovia", "Druesselstein", "Florin", "Graustark", "Rlenraven", "Hedestad", "Herzoslovakia", "Karlsberg", "Letzenstein", "Lissenberg", "Mittenheim", "Nordland", "Ruritania", "Westmark"];

//Red, Blue, Green, Yellow, Purple, Orange

function randshape() {
    emp1.push(Math.randomInt(1, 801), Math.randomInt(1, 601), Math.randomInt(10, 801), Math.randomInt(10, 601), names[Math.randomInt(0, names.length)]);
    emp2.push(Math.randomInt(1, 801), Math.randomInt(1, 601), Math.randomInt(10, 801), Math.randomInt(10, 601), names[Math.randomInt(0, names.length)]);
    emp3.push(Math.randomInt(1, 801), Math.randomInt(1, 601), Math.randomInt(10, 801), Math.randomInt(10, 601), names[Math.randomInt(0, names.length)]);
    emp4.push(Math.randomInt(1, 801), Math.randomInt(1, 601), Math.randomInt(10, 801), Math.randomInt(10, 601), names[Math.randomInt(0, names.length)]);
    

    ctx.fillStyle = "rgb(186, 9, 9)";
    ctx.fillRect(emp1[0], emp1[1], emp1[2], emp1[3]); 

    ctx.fillStyle = "rgb(157, 212, 19)";
    ctx.fillRect(emp2[0], emp2[1], emp2[2], emp2[3]);
    
    ctx.fillStyle = "rgb(19, 43, 194)";
    ctx.fillRect(emp3[0], emp3[1], emp3[2], emp3[3]);

    ctx.fillStyle = "rgb(232, 162, 23)";
    ctx.fillRect(emp4[0], emp4[1], emp4[2], emp4[3]);

    document.getElementById('name').innerHTML = emp1[4];
    document.getElementById('colour').innerHTML = "Red";
    document.getElementById('size').innerHTML = emp1[2] * emp1[3];
}





function selectciv() {
    
    let selection = document.getElementById('menu').value;

    // Take action based on menu selection
    if (selection == 'option1') {
        changenation(emp1[4],"Red",emp1[2] * emp1[3])
        
    } else if (selection == 'option2') {
        changenation(emp2[4],"Blue",emp2[2] * emp2[3])
        
    } else if (selection == 'option3') {
        changenation(emp3[4],"Green",emp3[2] * emp3[3])

    } else if (selection == 'option4') {
        changenation(emp4[4],"Orange",emp4[2] * emp4[3])

    }
}


randshape();

function changenation(name, colour, size) {
    document.getElementById('name').innerHTML = name;
    document.getElementById('colour').innerHTML = colour;
    document.getElementById('size').innerHTML = size;
}


