
document.getElementById('go').addEventListener('click', selectciv);



function selectciv() {
    
    let selection = document.getElementById('menu').value;

    // Take action based on menu selection
    if (selection == 'option1') {
        changeciv("America","American","Blue and White","George Washington", "OK", "#0a4e8a")
        
    } else if (selection == 'option2') {
        changeciv("Egypt","Egyptian","Yellow and Purple","Ramesses II", "Good", "#d6d691")
        
    } else if (selection == 'option3') {
        changeciv("Poland","Polish","Red and Black","Casimir III","Top Tier", "#d17272")

    } else if (selection == 'option4') {
        changeciv("Arabia", "Arabian", "Light and Dark Green", "Harun al-Rashid", "OK", "#477e42")

    } else if (selection == 'option5') {
        changeciv("Venice","Venetian", "White and Purple", "Enrico Dandolo", "Very Bad","#9257c9")

    } else if (selection == 'option6') {
        changeciv("France", "French", "Yellow and Blue", "Napoleon", "Bad", "#63cae4")

    }
}

function changeciv(name, adj, col, lead, rate, back) {
    document.getElementById('name').innerHTML = name;
    document.getElementById('adjective').innerHTML = adj;
    document.getElementById('colours').innerHTML = col;
    document.getElementById('leader').innerHTML = lead;
    document.getElementById('rating').innerHTML = rate;

    document.getElementById('mainimg').src = 'images/'+ name +'.png';

    document.body.style.backgroundColor = back;
}