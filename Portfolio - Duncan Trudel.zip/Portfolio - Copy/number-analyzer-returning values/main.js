// Number Analyzer

// HTML Elements
let numEl = document.getElementById('numInput');

// Add Event Listener
numEl.addEventListener('change', analyzeNumber);

// Event Function
function analyzeNumber() {
    // Get Number from Input Element
    let numInput = Number(numEl.value);

    // Analyze Number and display results
    document.getElementById('sign').innerHTML = getSign(numInput);
    document.getElementById('even-odd').innerHTML = evenOrOdd(numInput);
    document.getElementById('multiple').innerHTML = multipleOf10(numInput);
    document.getElementById('under100').innerHTML = under(numInput);
    document.getElementById('square').innerHTML = squared(numInput);
    document.getElementById('root').innerHTML = roots(numInput);
    document.getElementById('rating').innerHTML = duncanrating(numInput);

}


// Analyze Functions

    function getSign(num) {
    if (num > 0) {
        return "pos";
    } else if (num == 0) {
        return "zero";
    } else {
        return "neg";
    }
}

function evenOrOdd(num) {
    if (num % 2 == 0) {
        return "even";
    } else {
        return "odd";
    }
}

function multipleOf10(num) {
    if (num % 10 == 0) {
        return "true";
    } else {
        return "false";
    }
}

function under(num) {
    if (num >= 100) {
        return "false";
    } else {
        return "true";
    }
}

function squared(num) {
    return num**2;
}

function roots(num) {
    return Math.sqrt(num);
}

function duncanrating(num) {
    if ((num * 3)% 7 == 0) {
        return "terrible";
    } else if ((num + 4)% 7 == 1) {
        return "bad";
    } else if ((num + 4)% 7 == 2) {
        return "meh";
    } else if ((num + 4)% 7 == 3) {
        return "ok";
    } else if ((num + 4)% 7 == 4) {
        return "good";
    } else if ((num + 4)% 7 == 5) {
        return "great";
    } else if ((num + 4)% 7 == 6) {
        return "one of the best";
    } else {
        return "Amazing";
    }
}